﻿using System;
using MySql.Data.MySqlClient;
namespace Datos
{
    public class Class1
    {

        static string cadena = "datasource=127.0.0.1;username=root;password=root;database=concesionario";
        public MySqlConnection conexion = new MySqlConnection(cadena);



    }
}
