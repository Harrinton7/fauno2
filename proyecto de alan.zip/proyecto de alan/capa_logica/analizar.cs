﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using capa_datos;
namespace capa_logica
{
   public class analizar
    {
            datos_animales a = new datos_animales();
         public void id(int id1)
        {


         
            
        }

        public void regresar()
        {
           
        }

    }
}
