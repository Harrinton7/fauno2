﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;
using System.Windows.Forms;


namespace Datos
{
    class clase_general
    {



        public Class1 cn = new Class1();



        public DataTable command(string sql)
        {


            DataTable dt = new DataTable();

            try
            {
                MySqlCommand CM = new MySqlCommand(sql, cn.conexion);
                MySqlDataAdapter DA = new MySqlDataAdapter(CM);
                DA.Fill(dt);
                return dt;
            }
            catch (MySqlException e)
            {
                MessageBox.Show(e.ToString());
                return null;
            }
            finally
            {
                cn.conexion.Close();
            }




        }
    }
}

