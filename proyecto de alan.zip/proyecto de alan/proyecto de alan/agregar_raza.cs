﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proyecto_de_alan
{
    public partial class agregar_raza : Form
    {
        public agregar_raza()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            capa_logica.logica_raza j = new capa_logica.logica_raza();

            j.agregar_raza(txtNombre.Text);
        }
    }
}
