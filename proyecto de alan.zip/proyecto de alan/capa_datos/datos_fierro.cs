﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Windows.Forms;

namespace capa_datos
{
   public class datos_fierro
    {
        public void agregar(int id ,string descripcion,byte[] foto)
        {



            MySqlConnection conexionBD = Class1.conexion();
            conexionBD.Open();

            try
            {
                MySqlCommand comando = new MySqlCommand("INSERT INTO fierro(id_fierro ,descripcion,foto) VALUES ('" + id + "','" + descripcion + "', @foto)", conexionBD);
                comando.Parameters.AddWithValue("foto", foto);
                comando.ExecuteNonQuery();
                MessageBox.Show("Imagen guardada");

            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Error al guardar imagen " + ex.Message);
            }

        }


    }
}
