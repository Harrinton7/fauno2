﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Datos;

namespace logica
{
    class logica_animales
    {

        public DataTable ReadMarca(string x)
        {
            string sql = "SELECT * FROM animal";
            DataTable dt = new DataTable();
            Datos.datos_animales rc = new Datos.datos_animales();
            dt = rc.tblanimales(sql);

            return dt;
        }
    }
}
//WHERE descrip_marca LIKE '%" + x + "%'; "