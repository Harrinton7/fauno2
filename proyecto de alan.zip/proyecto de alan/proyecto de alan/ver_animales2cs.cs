﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using capa_logica;
using System.IO;





using System.Drawing.Imaging;

namespace proyecto_de_alan
{
    public partial class ver_animales2cs : Form
    {

        public ver_animales2cs()
        {
            InitializeComponent();
        }

        private void ver_animales2cs_Load(object sender, EventArgs e)
        {
            string chapa = textBoxnumchapa.Text;

            logica_animales cmb = new logica_animales();
            comboBoxcolor.DataSource = cmb.llenar();

            comboBoxcolor.DisplayMember = "descripcion";
            comboBoxcolor.ValueMember = "color";

            comboBoxfierro.DataSource = cmb.llenarfierro();

            comboBoxfierro.DisplayMember = "descripcion";
            comboBoxfierro.ValueMember = "fierro";

            comboBoxtipo.DataSource = cmb.llenartipo();

            comboBoxtipo.DisplayMember = "descripcion";
            comboBoxtipo.ValueMember = "tipo";

            comboBoxraza.DataSource = cmb.llenarraza();

            comboBoxraza.DisplayMember = "descripcion";
            comboBoxraza.ValueMember = "raza";
            comboBoxsexo.DataSource = cmb.llenarsexo();

            comboBoxsexo.DisplayMember = "descripcion";
            comboBoxsexo.ValueMember = "sexo";
        }


        void listarAnimales(string a)
        {

            capa_logica.logica_animales listarA = new capa_logica.logica_animales();
            dataGridView1.DataSource = listarA.ReadMarca(a);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            listarAnimales(textBox1.Text);

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

            OpenFileDialog ofdSeleccionar = new OpenFileDialog();
            ofdSeleccionar.Filter = "Imagenes|*.jpg; *.png";
            ofdSeleccionar.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);
            ofdSeleccionar.Title = "Seleccionar imagen";

            if (ofdSeleccionar.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = Image.FromFile(ofdSeleccionar.FileName);
            }


        }


        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }



        private void button1_Click(object sender, EventArgs e)
        {
            MemoryStream ms = new MemoryStream();
            pictureBox1.Image.Save(ms, ImageFormat.Jpeg);
            byte[] aByte = ms.ToArray();

            int fierro = Convert.ToInt32(comboBoxfierro.SelectedValue);
            int raza = Convert.ToInt32(comboBoxraza.SelectedValue);
            int sexo = Convert.ToInt32(comboBoxsexo.SelectedValue);
            int color = Convert.ToInt32(comboBoxcolor.SelectedValue);
            int tipo = Convert.ToInt32(comboBoxtipo.SelectedValue);
            capa_logica.logica_animales J = new logica_animales();
            J.agregar_animales(textBoxnumchapa.Text, textBoxnombre.Text, raza, color, aByte, tipo, fierro, sexo);

        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {

        }
        private void btnSeleccionar_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {



        }

        private void statusStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
    }
}
