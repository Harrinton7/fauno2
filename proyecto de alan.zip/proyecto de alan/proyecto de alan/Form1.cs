﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proyecto_de_alan
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            agregar_sexo i = new agregar_sexo();
            i.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            agregarestado i = new agregarestado();
            i.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            agregar_familia i = new agregar_familia();
            i.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            agregar_raza i = new agregar_raza();
            i.Show();
        }
    }
}
