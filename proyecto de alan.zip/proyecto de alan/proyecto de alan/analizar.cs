﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace proyecto_de_alan
{
    public partial class analizar : Form
    {
        ver_animales2cs v = new ver_animales2cs();
        public analizar()
        {
            InitializeComponent();
        }

        private void analizar_Load(object sender, EventArgs e)
        {
            
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

      
    }
}
