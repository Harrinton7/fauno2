﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace capa_logica
{
    public class logica_raza
    {
        public void agregar_raza(string descripcion)
        {
            capa_datos.datos_raza add = new capa_datos.datos_raza();
            add.agregar(descripcion);


        }
    }
}
