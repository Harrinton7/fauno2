﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using capa_datos;

namespace capa_logica
{
  public class logica_fierro
    {
        public void agregar_fierro(int id , string descripcion, byte[] foto)
        {
           capa_datos.datos_fierro add = new capa_datos.datos_fierro();
            add.agregar(id,descripcion, foto);


        }
    }
}
