﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace capa_logica
{
   public class logica_estado
    {
        public void agregar_estado(string descripcion)
        {
            capa_datos.datos_estado add = new capa_datos.datos_estado();
            add.agregar(descripcion);


        }
    }
}
