﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace proyecto_de_alan
{
    public partial class agregar_tratamiento : Form
    {
        public agregar_tratamiento()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
           
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            DateTime f = Convert.ToDateTime(dateTimePicker1.Text);

            capa_logica.logica_tratamiento j = new capa_logica.logica_tratamiento();

            j.agregar_tratamiento(txt_descripcion.Text, f,txt_dosis.Text);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void agregar_tratamiento_Load(object sender, EventArgs e)
        {

        }
    }
}
