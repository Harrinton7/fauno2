﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using capa_datos;

namespace capa_logica
{
    public class logica_tratamiento
    {
        public void agregar_tratamiento(string descripcion, DateTime fecha, string dosis)
        {
            capa_datos.datos_tratamiento add = new capa_datos.datos_tratamiento();
            add.agregar(descripcion, fecha, dosis);
        }
    }
}
