﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace capa_logica
{
   public class logica_familia
    {
        public void agregar_familia( string descripcion)
        {
            capa_datos.datos_familia add = new capa_datos.datos_familia();
            add.agregar( descripcion);


        }
    }
}
