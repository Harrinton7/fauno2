﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proyecto_de_alan
{
    public partial class agregar_familia : Form
    {
        public agregar_familia()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            capa_logica.logica_familia j = new capa_logica.logica_familia();
            
          j.agregar_familia( txtNombre.Text);
        }

        private void txtNombre_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
