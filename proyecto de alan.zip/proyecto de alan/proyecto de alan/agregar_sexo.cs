﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proyecto_de_alan
{
    public partial class agregar_sexo : Form
    {
        public agregar_sexo()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
                capa_logica.logica_sexo j = new capa_logica.logica_sexo();

                j.agregar_estado(txtNombre.Text);
            
        }

        private void agregar_sexo_Load(object sender, EventArgs e)
        {

        }
    }
}
