﻿using System;

namespace logica
{
    public class Class1
    {
    }
}
