﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using MySql.Data.MySqlClient;
using System.Windows.Forms;

namespace Datos
{
    public class datos_animales
    {
        Class1 cn = new Class1();
        public DataTable tblanimales(string sql)

        {
            DataTable dt = new DataTable();

            try
            {
                MySqlCommand CM = new MySqlCommand(sql, cn.conexion);
                MySqlDataAdapter DA = new MySqlDataAdapter(CM);
                DA.Fill(dt);
                return dt;
            }
            catch (MySqlException e)
            {
                MessageBox.Show(e.ToString());
                return null;
            }
            finally
            {
                cn.conexion.Close();
            }
        }
    }
}
