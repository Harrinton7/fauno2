﻿using System.Data;
using System.IO;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Drawing;
using System.Drawing.Drawing2D;


namespace capa_datos
{
    public class datos_animales
    {
        MySqlConnection conexionBD = Class1.conexion();
        Class1 cn = new Class1();
        public DataTable tblanimales(string sql)

        {
            DataTable dt = new DataTable();

            try
            {
                MySqlCommand CM = new MySqlCommand(sql, conexionBD);
                MySqlDataAdapter DA = new MySqlDataAdapter(CM);
                DA.Fill(dt);
                return dt;
            }
            catch (MySqlException e)
            {
                MessageBox.Show(e.ToString());
                return null;
            }
            finally
            {
                conexionBD.Close();
            }



        }
        public void agregar(string chapa, string nombre, int raza, int color, byte[] foto, int tipo, int fierro, int sexo)
        {



            MySqlConnection conexionBD = Class1.conexion();
            conexionBD.Open();

            try
            {
                MySqlCommand comando = new MySqlCommand("INSERT INTO animal(chapa,nombre,raza,color,foto,tipo,fierro,sexo) VALUES ('" + chapa + "','" + nombre + "','" + raza + "','" + color + "' , @foto , '" + tipo + "','" + fierro + "','" + sexo + "')", conexionBD);
                comando.Parameters.AddWithValue("foto", foto);
                comando.ExecuteNonQuery();
                MessageBox.Show("Imagen guardada");

            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Error al guardar imagen " + ex.Message);
            }

        }
        public void Mostrar(int id)
        {

            string sql = "SELECT nombre, imagen FROM fotos WHERE id='" + id + "'";

            MySqlConnection conexionBD = Class1.conexion();
            conexionBD.Open();

            try
            {
                MySqlCommand comando = new MySqlCommand(sql, conexionBD);
                MySqlDataReader reader = comando.ExecuteReader();


               
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Error al buscar " + ex.Message);
            }


            
            

        }
        

    }

    }

    

