﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using capa_datos;
using System.IO;
using MySql.Data.MySqlClient;

namespace capa_logica
{
    public class logica_animales
    {
        public DataTable ReadMarca(string x)
       {
            string sql = "SELECT * FROM animal WHERE chapa LIKE'%" + x + "%'; ";
            DataTable dt = new DataTable();
            capa_datos.datos_animales rc = new capa_datos.datos_animales();
            dt = rc.tblanimales(sql);

            return dt;
        }
        public DataTable llenar()
        {
            string sql = "SELECT color , descripcion  FROM animal,color";
            DataTable dt = new DataTable();
            capa_datos.datos_animales rc = new capa_datos.datos_animales();
            dt = rc.tblanimales(sql);

            return dt;
        }
        public DataTable llenarraza()
        {
            string sql = "SELECT raza , descripcion  FROM animal,raza";
            DataTable dt = new DataTable();
            capa_datos.datos_animales rc = new capa_datos.datos_animales();
            dt = rc.tblanimales(sql);

            return dt;
        }
        public DataTable llenartipo()
        {
            string sql = "SELECT tipo , descripcion  FROM animal,tipo_animal";
            DataTable dt = new DataTable();
            capa_datos.datos_animales rc = new capa_datos.datos_animales();
            dt = rc.tblanimales(sql);

            return dt;
        }
        public DataTable llenarfierro()
        {
            string sql = "SELECT fierro , descripcion  FROM animal,fierro";
            DataTable dt = new DataTable();
            capa_datos.datos_animales rc = new capa_datos.datos_animales();
            dt = rc.tblanimales(sql);

            return dt;
        }
        public DataTable llenarsexo()
        {
            string sql = "SELECT sexo , descripcion  FROM animal,sexo";
            DataTable dt = new DataTable();
            capa_datos.datos_animales rc = new capa_datos.datos_animales();
            dt = rc.tblanimales(sql);

            return dt;
        }
        public void agregar_animales( string chapa, string nombre, int raza, int color, byte[]foto, int tipo, int fierro, int sexo)
        {


           
            datos_animales add = new datos_animales();
            add.agregar(chapa,nombre,raza,color,foto,tipo,fierro,sexo);

       
        }

       

        
            

        
    }
}
