﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Windows.Forms;

namespace capa_datos
{
   public class agregar_color
    {

        public void agregar( string descripcion)
        {



            MySqlConnection conexionBD = Class1.conexion();
            conexionBD.Open();

            try
            {
                MySqlCommand comando = new MySqlCommand("INSERT INTO color(descripcion) VALUES ('"  + descripcion + "')", conexionBD);
               
                comando.ExecuteNonQuery();
                MessageBox.Show("datos guardados");

            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Error al guardar datos " + ex.Message);
            }

        }
    }
}
