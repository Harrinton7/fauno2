﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace capa_datos
{
    public class datos_tratamiento
    {
        public void agregar(string descripcion, DateTime fecha , string dosis)
        {



            MySqlConnection conexionBD = Class1.conexion();
            conexionBD.Open();

            try
            {
                MySqlCommand comando = new MySqlCommand("INSERT INTO tramiento(descripcion, fecha, dosis) VALUES ('" + descripcion + "','" + fecha + "','" + dosis + "')", conexionBD);

                comando.ExecuteNonQuery();
                MessageBox.Show("datos guardados");

            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Error al guardar datos " + ex.Message);
            }
        }
    }
}
